# تصميم الخدمات الخلفية وواجهات API — منصة حوكمة APIs
**الإصدار:** v0.1 — مرحلة المعمارية التقنية / الخدمات الخلفية — تصميم للمراجعة، وليس تطبيقًا منفذًا.
**المرجع المعتمد:** نموذج قاعدة البيانات المنطقي v0.1 (43 جدولًا)، والتصاميم الوظيفية المعتمدة حديثًا. مفاتيح الجداول وأسماؤها من المرجع دون استبدالها.
**قرار معتمد من المستخدم:** وثيقة API واحدة ترتبط بتكامل واحد ضمن النطاق الحالي؛ لا يغيّر هذا الملف العلاقة.

## 1. الحدود والمبادئ
- الخادم هو المصدر الوحيد للحقيقة للهوية والصلاحيات والحالات والملفات؛ الواجهة الحالية مرجع UX/UI ولا تعد بنية آمنة جاهزة للنشر.
- البنية المقترحة: **خادم واحد منظّم إلى وحدات (Modular Monolith)** وخدمات تشغيلية داخلية؛ تجنّب الخدمات المصغرة قبل ظهور حاجة موثقة. هذا اقتراح معماري، وليس اختيارًا نهائيًا للغة أو إطار العمل.
- قاعدة بيانات علائقية واحدة وسجل معاملات؛ الملفات الثنائية في تخزين خاص وغير قابل للتنفيذ، وقاعدة البيانات تحتفظ بالوصف والبصمة والموقع.
- اتصال HTTPS وهوية موثقة؛ تحديد طريقة المصادقة (هوية المؤسسة أو بديل مؤقت) في قرار منفصل، دون افتراض Active Directory.
- كل ردّ موجّه إلى جهة خارجية يمر بفلترة الجهة والوثيقة والمنشور النشط؛ يمنع الاعتماد على إخفاء الأزرار في الواجهة.
- لا يوجد تجاوز تلقائي بسبب اسم دور «مدير النظام» أو «مطور»؛ أي صلاحية قابلة للمنح أو السحب، ويظل التعيين ومسار العمل شرطًا تشغيليًا مستقلًا.

## 2. وحدات الخادم ومسؤولياتها
| الوحدة | المسؤوليات | مجموعات البيانات |
|---|---|---|
| Identity & Access | الحسابات والأدوار والصلاحيات الشاملة والفردية؛ حاصل جميع الأدوار ثم الاستثناء الفردي؛ مصفوفة صلاحيات الوثيقة | users / roles / user_roles / permissions / role_permissions / user_permission_overrides / document_*_permissions |
| Master Data | أنظمة الشركة ومزودو API ومجموعات API والجهات المستهلكة وتصنيفاتها | company_systems / internal_provider_systems / external_provider_systems / consumer_entities / api_groups |
| Configuration | أنواع الملفات وقوالبها ومسارات الاعتماد وأنواع وسياسات التغيير؛ حماية الإصدارات السابقة من تغييرات الإعداد | file_types / requirement_templates / approval_routes / change_types / change_policies |
| Documents | العلاقة الأساسية المزود↔المستهلك، تحقق عدم تطابق النظام الداخلي في الطرفين، التعيين والتحكم على مستوى الوثيقة | api_documents / document_developers / document_role_permissions / document_user_permissions |
| Integrations | إنشاء تكامل وحيد لكل وثيقة، وتعيين مطورين، وحماية حذف الوثيقة المرتبطة | integrations / integration_developers |
| Versions & Files | تسمية إصدار API يدويًا، مراجعات توثيق مستقلة، نسخ ملفات غير قابلة للتعديل، وتحقق متطلبات الرفع | api_versions / document_revisions / revision_file_requirements / file_objects / revision_files |
| Change Management | طلب تغيير سابق لأي تعديل بعد اعتماد الحزمة، وتقييد أنواع الملفات المسموح تعديلها | change_requests / change_request_files |
| Workflow Engine | نسخة ثابتة من مراحل المسار، دور مسؤول لكل مرحلة، قرار واحد يستهلك المرحلة بطريقة ذرية | workflow_runs / workflow_run_stages / workflow_decisions |
| Publishing & Portal | النشر المستقل عن الاعتماد، إيقاف النشر، إصدار واحد مستخدم للمستهلك، وإتاحة المصرح به فقط | publications / publication_files / consumer_version_usage |
| Audit & Notifications | تسجيل الأحداث والإشعارات ولوحة التحكم والبحث المفلتر | audit_events / release_history_events / notifications |

## 3. معيار API موحد — مقترح
- المسار الأساسي `/api/v1`، وبيانات الطلب والرد بصيغة JSON؛ رفع الملفات عبر multipart/form-data أو تدفق محسوب الحجم، والتنزيل عبر الخادم مع تدقيق وليس عبر رابط تخزين عام.
- المصادقة تُنفّذ على الخادم بالآلية التي تعتمدها المؤسسة لاحقًا؛ كل طلب يحمل سياق المستخدم والجهة وليس roleId يختاره العميل.
- الأخطاء بتنسيق ثابت `{code,message,details,traceId}`؛ رسائل عربية/إنجليزية بحسب `Accept-Language`، ولا يظهر تفاصيل قاعدة البيانات أو التخزين في الأخطاء.
- استخدام `GET` للقراءة، و`POST` لإنشاء الموارد/القرارات، و`PATCH` للتعديل الجزئي، و`PUT` لاستبدال المصفوفات كاملة مع كشف التعارضات.
- الطلبات المسببة لتغييرات حرجة، مثل إصدار قرار اعتماد أو نشر، تدعم مفتاح إعادة المحاولة `Idempotency-Key` أو معرّف عملية ثابتًا، وتمنع التكرار.
- الاستجابة الناجحة لعملية ذات انتقال حالة تشمل الحالة الجديدة ومعرّف الحدث؛ القرارات المعتمدة تُكتب في معاملة واحدة مع سجل التدقيق.
- حالات HTTP: `400` صيغة، `401` لا هوية، `403` منع إجراء/سجل، `404` غير موجود أو محجوب، `409` تعارض حالة/نسخة، `422` شروط العمل غير متحققة، `413` حجم ملف أكبر من المحدد.
- ترقيم صفحات ثابت مع sort وfilter على مستوى الخادم؛ لا يجوز إرجاع سجلات محجوبة ثم تصفيتها في المتصفح.
- توليد وصف OpenAPI قابل للتحقق في مرحلة التنفيذ؛ النسخة المستهدفة تُحدد عند اختيار إطار العمل والأدوات.

## 4. كتالوج واجهات الخدمات — 93 مسارًا أوليًا
> هذا **كتالوج عمليات للتصميم** لا يثبت تنفيذ أي واجهة. عمود الإذن يعرض أمثلة لأكواد صلاحيات مقترحة تُطابق لاحقًا بقاموس `permissions`، ولا يمثّل صلاحيات مقفلة على أدوار بعينها.

### الحسابات والأدوار
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `GET` | `/api/v1/me` | الهوية والأدوار والصلاحيات الفعلية | مستخدم موثق |
| `GET` | `/api/v1/users` | قائمة المستخدمين | users.view |
| `POST` | `/api/v1/users` | إضافة مستخدم | users.create |
| `PATCH` | `/api/v1/users/{userId}` | تعديل بيانات المستخدم وتفعيل الحساب | users.edit |
| `PUT` | `/api/v1/users/{userId}/roles` | استبدال مجموعة أدوار المستخدم ذرّيًا | users.assign_roles |
| `GET` | `/api/v1/users/{userId}/permissions` | المصفوفة الفعلية والموروثة والاستثناءات | permissions.view |
| `PUT` | `/api/v1/users/{userId}/permission-overrides` | منح وسحب استثناءات فردية | permissions.manage |
| `GET` | `/api/v1/roles` | قائمة الأدوار | roles.view |
| `POST` | `/api/v1/roles` | إنشاء دور | roles.create |
| `PATCH` | `/api/v1/roles/{roleId}` | تعديل الدور/تثبيته/تعطيله | roles.edit |
| `PUT` | `/api/v1/roles/{roleId}/permissions` | استبدال منح الدور | permissions.manage |
| `GET` | `/api/v1/permissions` | قاموس الصلاحيات الدائم للقراءة | permissions.view |
| `DELETE` | `/api/v1/roles/{roleId}` | إزالة دور غير مستخدم وفق قواعد الأرشفة؛ لا يحذف قاموس الصلاحيات | roles.delete |

### التعريفات والتهيئة
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `GET` | `/api/v1/company-systems` | عرض أنظمة الشركة | company_systems.view |
| `POST` | `/api/v1/company-systems` | إضافة نظام داخلي | company_systems.create |
| `PATCH` | `/api/v1/company-systems/{systemId}` | تعديل/تعطيل نظام داخلي | company_systems.edit |
| `GET` | `/api/v1/internal-providers` | عرض الأنظمة الداخلية المزودة | providers.view |
| `POST` | `/api/v1/internal-providers` | تفعيل نظام شركة كمزود دون تكرار | providers.create |
| `GET` | `/api/v1/external-providers` | عرض المزودين الخارجيين | providers.view |
| `POST` | `/api/v1/external-providers` | إضافة مزود خارجي | providers.create |
| `GET` | `/api/v1/consumer-categories` | تصنيفات الجهات | consumers.view |
| `POST` | `/api/v1/consumer-categories` | إضافة تصنيف | consumers.manage |
| `GET` | `/api/v1/consumers` | قائمة الجهات المستهلكة | consumers.view |
| `POST` | `/api/v1/consumers` | إضافة جهة مستهلكة | consumers.manage |
| `GET` | `/api/v1/api-groups` | مجموعات API | api_groups.view |
| `POST` | `/api/v1/api-groups` | إنشاء مجموعة | api_groups.manage |
| `GET` | `/api/v1/file-types` | أنواع الملفات وامتداداتها | file_types.view |
| `POST` | `/api/v1/file-types` | تعريف نوع من كتالوج الأنواع المعتمد | file_types.manage |
| `GET` | `/api/v1/requirement-templates` | قوالب متطلبات الملفات | requirements.view |
| `POST` | `/api/v1/requirement-templates` | إنشاء قالب متطلبات وقيوده | requirements.manage |
| `GET` | `/api/v1/approval-routes` | قائمة مسارات الاعتماد ومراحلها | routes.view |
| `POST` | `/api/v1/approval-routes` | إنشاء مسار اعتماد | routes.manage |
| `PUT` | `/api/v1/approval-routes/{routeId}/stages` | حفظ مراحل الدور مرتبة دون نوع مرحلة | routes.manage |
| `GET` | `/api/v1/change-types` | أنواع طلبات التغيير ومساراتها | changes.config.view |
| `POST` | `/api/v1/change-types` | إضافة نوع تغيير | changes.config.manage |
| `GET` | `/api/v1/change-policies` | سياسات التغيير | changes.config.view |
| `PATCH` | `/api/v1/internal-providers/{providerId}` | تفعيل أو تعطيل مزود داخلي مع الحفاظ على أصل نظام الشركة | providers.edit |
| `PATCH` | `/api/v1/external-providers/{providerId}` | تعديل أو تعطيل مزود خارجي | providers.edit |
| `PATCH` | `/api/v1/consumer-categories/{categoryId}` | تعديل تصنيف جهة | consumers.manage |
| `PATCH` | `/api/v1/consumers/{consumerId}` | تعديل أو تعطيل جهة مستهلكة | consumers.manage |
| `PATCH` | `/api/v1/api-groups/{groupId}` | تعديل أو تعطيل مجموعة API | api_groups.manage |
| `PATCH` | `/api/v1/file-types/{fileTypeId}` | تعديل حجم نوع الملف أو تفعيله وإعدادات القالب وفق كتالوج الامتدادات | file_types.manage |
| `PATCH` | `/api/v1/requirement-templates/{templateId}` | تعديل قالب متطلبات ملف قبل استخدامه مع حفظ اللقطات التاريخية | requirements.manage |
| `PATCH` | `/api/v1/approval-routes/{routeId}` | تعديل اسم المسار أو حالته دون التأثير في المعاملات الجارية | routes.manage |
| `PATCH` | `/api/v1/change-types/{typeId}` | تعديل نوع تغيير أو ربطه بمسار | changes.config.manage |
| `POST` | `/api/v1/change-policies` | إنشاء سياسة تغيير | changes.config.manage |
| `PATCH` | `/api/v1/change-policies/{policyId}` | تعديل سياسة تغيير للوثائق الجديدة أو المخوّلة | changes.config.manage |

### وثائق API والتفويض
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `GET` | `/api/v1/api-documents` | وثائق مرئية للمستخدم فقط | api_documents.view + doc.view |
| `POST` | `/api/v1/api-documents` | إنشاء وثيقة مقيدة وعلاقاتها | api_documents.create |
| `GET` | `/api/v1/api-documents/{documentId}` | تفاصيل وثيقة محددة | api_documents.view + doc.view |
| `PATCH` | `/api/v1/api-documents/{documentId}` | تعديل الإعدادات وفق حالة الارتباط | api_documents.edit + doc.edit |
| `DELETE` | `/api/v1/api-documents/{documentId}` | حذف غير المرتبطة فقط/قواعد الأرشفة | api_documents.delete + doc.delete |
| `GET` | `/api/v1/api-documents/{documentId}/access` | قراءة مصفوفة صلاحيات الوثيقة | documents.permissions.view + doc.access.manage |
| `PUT` | `/api/v1/api-documents/{documentId}/access` | منح وسحب الوثيقة لكل دور/مستخدم | documents.permissions.manage + doc.access.manage |
| `PUT` | `/api/v1/api-documents/{documentId}/developers` | إسناد المطورين المخولين للوثيقة | api_documents.assign_developer + doc.assign |
| `GET` | `/api/v1/api-documents/{documentId}/developers` | قراءة المطورين المعيّنين | api_documents.view + doc.view |

### التكاملات والإصدارات والملفات
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `GET` | `/api/v1/integrations` | قائمة التكاملات المسموحة | integrations.view + doc.view |
| `POST` | `/api/v1/integrations` | إنشاء تكامل من وثيقة غير مرتبطة | integrations.create + doc.manage_integration |
| `GET` | `/api/v1/integrations/{integrationId}` | ملخص التكامل مع فحص الوثيقة | integrations.view + doc.view |
| `PUT` | `/api/v1/integrations/{integrationId}/developers` | إسناد مطورين للتكامل | integrations.assign_developer + doc.assign |
| `GET` | `/api/v1/integrations/{integrationId}/versions` | سرد إصدارات API اليدوية | versions.view + doc.view |
| `POST` | `/api/v1/integrations/{integrationId}/versions` | إنشاء إصدار حر بالرقم اليدوي | versions.create + doc.version_manage + تعيين |
| `GET` | `/api/v1/versions/{versionId}/revisions` | قائمة مراجعات التوثيق للإصدار | revisions.view + doc.view |
| `POST` | `/api/v1/versions/{versionId}/revisions` | نسخة عمل أولية أو بعد طلب تغيير معتمد | revisions.create + doc.edit + تعيين |
| `GET` | `/api/v1/revisions/{revisionId}` | تفاصيل مراجعة حزمة الملفات | revisions.view + doc.view |
| `POST` | `/api/v1/revisions/{revisionId}/files` | رفع ملف جديد مع الفحص والقيود | files.upload + doc.files_manage + تعيين |
| `DELETE` | `/api/v1/revisions/{revisionId}/files/{fileId}` | إزالة ربط الملف في مسودة قابلة للتعديل | files.delete + doc.files_manage + تعيين |
| `GET` | `/api/v1/revisions/{revisionId}/files/{fileId}/download` | تنزيل مرخص من تخزين خاص | files.download + doc.view |
| `POST` | `/api/v1/revisions/{revisionId}/submit` | إرسال حزمة مكتملة للمراجعة | revisions.submit + doc.edit + تعيين |
| `GET` | `/api/v1/integrations/{integrationId}/developers` | قراءة المطورين المعيّنين للتكامل | integrations.view + doc.view |
| `GET` | `/api/v1/revisions/{revisionId}/files` | قائمة الملفات ومتطلباتها والحالة | files.view + doc.view |

### طلبات التغيير وسير العمل
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `GET` | `/api/v1/integrations/{integrationId}/change-requests` | عرض طلبات تغيير التكامل | changes.view + doc.view |
| `POST` | `/api/v1/integrations/{integrationId}/change-requests` | إنشاء طلب تغيير للملفات المعتمدة | changes.create + doc.change + تعيين |
| `POST` | `/api/v1/change-requests/{requestId}/submit` | بدء مسار موافقة الطلب | changes.submit + doc.change + تعيين |
| `GET` | `/api/v1/workflows/inbox` | الطلبات المنتظرة حسب جميع الأدوار | workflows.view + أهلية |
| `GET` | `/api/v1/workflows/{runId}` | تفاصيل المسار والقرار ونسخة المراحل | workflows.view + doc.view |
| `POST` | `/api/v1/workflows/{runId}/stages/{stageId}/decisions` | موافقة أو إعادة أو رفض من عضو واحد مؤهل | workflows.decide + دور المرحلة + doc.review |
| `GET` | `/api/v1/workflows/{runId}/history` | سجل قرارات المحاولات | workflows.view + doc.view |
| `GET` | `/api/v1/change-requests/{requestId}` | تفاصيل الطلب وملفاته ومساره | changes.view + doc.view |
| `PATCH` | `/api/v1/change-requests/{requestId}` | تعديل طلب في حالة المسودة قبل الإرسال | changes.edit + doc.change + تعيين |

### النشر والبوابة
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `POST` | `/api/v1/revisions/{revisionId}/publications` | نشر ملفات مختارة من مراجعة معتمدة | publications.create + doc.publish |
| `POST` | `/api/v1/publications/{publicationId}/withdraw` | إيقاف نشر مع إبقاء السجل | publications.withdraw + doc.publish |
| `GET` | `/api/v1/integrations/{integrationId}/consumer-version` | الإصدار الجاري استخدامه | versions.usage.view + doc.view |
| `PUT` | `/api/v1/integrations/{integrationId}/consumer-version` | تعيين إصدار واحد منشور للاستخدام | versions.usage.manage + doc.publish |
| `GET` | `/api/v1/portal/integrations` | قائمة المنشور لجهة المستهلك الموثقة | بوابة: جهة المستخدم + نشر نشط |
| `GET` | `/api/v1/portal/publications/{publicationId}/files` | ملفات منشورة مسموحة للجهة | بوابة: جهة المستخدم + ملف منشور |
| `GET` | `/api/v1/portal/publications/{publicationId}/files/{fileId}/download` | تنزيل ملف منشور مع تدقيق | بوابة: جهة المستخدم + نشر نشط |
| `GET` | `/api/v1/integrations/{integrationId}/publications` | تاريخ النشر بحسب الإصدار | publications.view + doc.view |

### المراقبة والتدقيق
| HTTP | المسار | العملية | شرط الوصول المبدئي |
|---|---|---|---|
| `GET` | `/api/v1/notifications` | إشعارات المستخدم الحالي | المستخدم نفسه |
| `POST` | `/api/v1/notifications/{notificationId}/read` | تحديد إشعار مقروءًا | المستخدم نفسه |
| `GET` | `/api/v1/audit-events` | عرض أحداث التدقيق وفق نطاق التصريح | audit.view |
| `GET` | `/api/v1/search` | بحث مصفّى بإذن الوثيقة | search.view + doc.view |
| `GET` | `/api/v1/dashboard` | إحصاءات مبنية على البيانات المصرح بها | dashboard.view + نطاق البيانات |

## 5. محرك الصلاحيات والتعيين
**5.1 صلاحية عامة:** `effective = userOverride إن وجد، وإلا OR(rolePermissions لكل الأدوار النشطة)`. الاستثناء الفردي `REVOKE` يتقدم على منح جميع الأدوار. لا يُحذف رمز صلاحية من القاموس.
**5.2 صلاحية الوثيقة:** يُحسب السماح المستقل على الوثيقة من `document_user_permissions` أولًا ثم `document_role_permissions`؛ الوثيقة الجديدة مقيدة افتراضيًا. **قاعدة مقترحة للمراجعة:** في حال وجود منح وسحب متضاربين عبر أدوار الوثيقة المختلفة يُغلب السحب، والاستثناء الفردي يتقدم عليهما. يجب حسم هذه القاعدة قبل البرمجة.
**5.3 الوصول الفعلي:** سماح إجراء عام **و** سماح على الوثيقة/العلاقة. للقرارات والإجراءات المسندة يضاف التحقق من عضوية المستخدم في الدور المسؤول للمرحلة أو من تعيينه مطورًا للعمل. لا يخول اسم الدور بذاته تجاوزًا.
**5.4 استثناء مهام المراجع:** لتجنب أن تصبح وثيقة مخفية غير قابلة للمراجعة عند إسناد دور مسؤول، تنشأ صلاحية وصول **مؤقتة ومحدودة بالمعاملة والملفات اللازمة** للمستخدمين المؤهلين للمرحلة. لا تتيح تحرير الوثيقة أو الاطلاع الشامل على جميع بياناتها. هذا نمط مقترح يحتاج إقرارًا دقيقًا في سياسة الوصول.
**5.5 المستخدِم الخارجي:** تعتمد البوابة هوية الجهة المستهلكة وحالة النشر/ملف النشر؛ لا تُعتبر صلاحيات الإدارة الداخلية شرطًا لعرض المستهلك المنشورات.

## 6. انتقالات الحالات المسموحة
| المورد | الحالة الحالية | الإجراء | الحالة الناتجة | ضوابط أساسية |
|---|---|---|---|---|
| مراجعة ملفات | DRAFT | submit | IN_REVIEW | متطلبات الملفات متحققة؛ الدور الأول يضم عضوًا مؤهلًا |
| سير مراجعة | IN_REVIEW | approve current stage | NEXT_STAGE أو APPROVED | قفل المرحلة؛ عضو واحد يقرر؛ عند الأخيرة يكتمل |
| سير مراجعة | IN_REVIEW | return | RETURNED | سبب الإعادة؛ إنشاء محاولة جديدة عند إعادة التقديم |
| سير مراجعة | IN_REVIEW | reject | REJECTED | قرار نهائي ومحفوظ؛ إعادة الإرسال بمراجعة جديدة عند السماح |
| طلب تغيير | DRAFT | submit | UNDER_APPROVAL | نوع تغيير ومسار متاح وملفات متأثرة محددة |
| طلب تغيير | UNDER_APPROVAL | approve final stage | APPROVED | يُسمح بعده بإنشاء مراجعة عمل فقط للملفات المحددة |
| مراجعة معتمدة | APPROVED | change revision | NEW DRAFT | لا تعديل للأصل؛ طلب تغيير معتمد |
| نشر | NOT_PUBLISHED | publish | PUBLISHED | مراجعة معتمدة؛ ملفات من المراجعة؛ إذن نشر |
| نشر | PUBLISHED | withdraw | WITHDRAWN | إيقاف الوصول فورًا دون حذف سجل النشر |
| إصدار مستخدم | version A | activate B | version B | الإصدار B منشور وصالح؛ إغلاق الاستخدام A ذريًا |
**تحذير تصميمي:** أسماء الحالات أعلاه مقترحة وليست قاموس حالات مُعتمدًا نهائيًا في قاعدة البيانات. يُحسم قاموس الحالات عند الانتقال للمخطط الفيزيائي وتوقيع العقود.

## 7. تسلسلات العمل ومبدأ الذرّية
### 7.1 إنشاء وثيقة وتكامل
1. يتحقق `Documents` من المزود والمستهلك والمجموعة وتفعيل القوالب ومسارات الاعتماد.
2. تُنشأ `api_documents` و`document_developers` وأذونات الوصول الأولية ضمن معاملة واحدة؛ لا يكوّن الاسم يدويًا.
3. `Integrations` ينشئ تكاملًا واحدًا فقط للوثيقة؛ قيد التفرد في قاعدة البيانات يمنع السباق.
### 7.2 المراجعة والاعتماد
1. عند التقديم تُنسخ المراحل والأدوار إلى `workflow_run_stages` وتُتحقق أهلية الدور الأول.
2. `Workflow` يتحقق من الدور والصلاحيات وسياق الملف قبل قبول القرار، ثم ينتقل بالمعاملة إلى الدور التالي.
3. يُنفذ حجز/تحديث شرطي لحالة المرحلة حتى لا يوافق مستخدمان في الوقت نفسه؛ قرار واحد مؤثر ونتيجة تكرار معروفة.
4. بعد آخر مرحلة تُعتمد `document_revisions` أو `change_requests` بحسب نوع سير العمل.
### 7.3 ترقية إصدار أو مراجعة توثيق
1. المطور المعيّن والمخول يقدم طلب تغيير ويحدد الملفات المتأثرة؛ تراجع اللجنة عبر دور كل مرحلة، ولا يوجد تجاوز تلقائي لدور مدير النظام.
2. عند الموافقة، يستطيع المطور إنشاء نسخة عمل جديدة لإصدار API جديد برقم حر أو تحديث مراجعة التوثيق لنفس الإصدار، وفق أثر التغيير.
3. تُعاد الإشارة للملفات غير المتأثرة وتُنشأ كائنات ثنائية جديدة للملفات المتغيرة؛ لا تُستبدل ملفات المراجعة الأصلية.
4. تخضع المراجعة الجديدة لمسار اعتمادها، ثم تُنشر وحدها وتُوثّق في سجل الإصدار.
### 7.4 إخراج ملفات النشر للمستهلك
1. تُراجع صلاحية الناشر وصلاحية الوثيقة والمراجعة المعتمدة، وتُحدد فقط الملفات المنشورة.
2. يحقق تنزيل المستهلك أن `consumer_entity_id` في الهوية يطابق الجهة المستهلكة وأن `publications.state = PUBLISHED` والملف ضمن `publication_files`.
3. يصدر محتوى الملف عبر الخادم بعد التحقق وتسجيل الحدث، دون رابط تخزين قابل للتخمين.

## 7.5 عقود عمليات نموذجية (تصميم، غير تنفيذي)
**إنشاء وثيقة:** `POST /api/v1/api-documents` يُرسل مراجع المزود والمستهلك والمجموعة وقالب الملفات ومسار الموافقة وسياسة التغيير والنشر، وقائمة المطورين. لا يرسل العميل اسم الوثيقة، ولا يمنح نفسه صلاحيات تتجاوز السياسة.
```json
{
  "provider": {
    "kind": "internal",
    "systemId": "<UUID>"
  },
  "consumer": {
    "kind": "external",
    "entityId": "<UUID>"
  },
  "apiGroupId": "<UUID>",
  "requirementTemplateId": "<UUID>",
  "approvalRouteId": "<UUID>",
  "changePolicyId": "<UUID>",
  "publicationOption": "authorized-consumer",
  "developerUserIds": [
    "<UUID>"
  ]
}
```
**قرار اعتماد:** `POST /api/v1/workflows/{runId}/stages/{stageId}/decisions` بقرار `APPROVE` أو `RETURN` أو `REJECT`، ويُطلب سبب عند الإعادة/الرفض. لا يقبل العميل إرسال `actorUserId` أو `roleId` لصنع أهلية مزيفة؛ تُستخرج الهوية والأدوار من جلسة الخادم.
```json
{
  "decision": "RETURN",
  "notes": "يرجى استكمال مواصفات الأخطاء",
  "expectedStageStatus": "PENDING"
}
```
**تعديل صلاحيات الوثيقة:** `PUT /api/v1/api-documents/{documentId}/access` يتعامل مع مجموعة أحكام `GRANT/REVOKE` وفق معرف المستخدم/الدور ورمز الإجراء، مع تزامن آمن عبر رقم مراجعة الإعدادات أو شرط If-Match.
**نشر الملفات:** `POST /api/v1/revisions/{revisionId}/publications` يقبل فقط `revisionFileIds` التابعة للمراجعة المعتمدة ويعيد `publicationId` وحالة النشر.
**تنبيه توافق قاعدة البيانات:** حقل `publication_option` معرّف كسلسلة في النموذج المنطقي؛ القيمة المعروضة مثال لحقل عقد API ويجب توافقها مع قاموس القيم عند اعتمادها.

## 8. متطلبات الأمان والاعتمادية وإجراءات الفشل
- فحص هوية وصلاحية على مستوى الوظيفة **والسجل** في كل Endpoint، ومنع الوصول إلى خصائص السجلات غير المصرح بها. راجع OWASP API1/API3/API5.
- تحقق خادم من الحجم والامتداد والتوقيع الفعلي/نوع المحتوى، وفحص البرمجيات الخبيثة، وعزل الملف في حالة فحص حتى يصبح آمنًا؛ منع التنفيذ في مخزن الملفات.
- كل قرار واعتماد/سحب صلاحية/نشر/تنزيل يُسجل بما يلائم حساسية العملية، ولا تسمح الواجهة أو الخدمة بحذف سجلات التدقيق.
- تنفيذ التغييرات متعددة الجداول داخل Transactions؛ استخدام Outbox/Queue اختياري لإرسال الإشعارات دون فقد أحداثها إذا فشل الإرسال.
- فرض تفرد (version label داخل التكامل) وتفرد مرحلة القرار وتفرد تكامل الوثيقة في قاعدة البيانات إضافة لفحص الخادم.
- توليد Word بالمراجعة النهائية مشتق جديد مع بصمة وتوثيق مستقل؛ لا تُكتب التعديلات على النسخة الأصلية، ويحتاج اختبار القوالب الحقيقية قبل اعتماد الحل.
- واجهة إعادة المحاولة تكشف `409` للتعارض و`422` لعدم استيفاء الشروط برسائل مفيدة دون تسريب بيانات.
- تحديد سياسات الاحتفاظ والنسخ الاحتياطي وحدود الحجم والمعدلات وRPO/RTO لاحقًا مع IT؛ لا يُفترض رقم أو ضمان غير معتمد.
- اختبارات اعتمادية من نوع «تزامن مراجعين يقرران في اللحظة نفسها»، «سحب صلاحية أثناء الطلب»، «رفع يتوقف وسط النقل»، «إيقاف نشر قبل تنزيل».
- إعادة الفحص على الخادم حتى بعد تحقق الواجهة، باستخدام اختبار آلي لتجاوز الصلاحيات (BOLA/BFLA).
**مراجع تقنية:** [OWASP API Security](https://owasp.org/projects/api-security-project)، [OWASP Object Level Authorization](https://api-security.owasp.org/editions/2023/en/0xa1-broken-object-level-authorization/)، [OpenAPI Specification](https://spec.openapis.org/oas/latest.html)، [Microsoft Secure File Upload Guidance](https://learn.microsoft.com/aspnet/core/mvc/models/file-uploads).

## 9. سيناريوهات قبول قابلة للاختبار (مطلوبة قبل التسليم للتطوير)
| المعرّف | شرط القبول |
|---|---|
| AUTH-01 | جمع أدوار متعددة؛ مستخدم له دور مراجع ودور ناشر يرى اتحاد الصلاحيات |
| AUTH-02 | سحب فردي يزيل صلاحية موروثة من دورين دون تغيير صلاحيات أعضاء الدور الآخرين |
| AUTH-03 | صلاحية شاشة فقط لا تتيح فتح وثيقة مقيّدة، حتى بمعرّف URL مباشر |
| AUTH-04 | منح الوثيقة A لا يتيح الوثيقة B أو أي تكامل تابع لها |
| AUTH-05 | المستخدم المعيّن في دور المرحلة يستطيع المراجعة مع الوصول المقيد الضروري فقط |
| AUTH-06 | إجراء اعتماد بلا عضوية دور المرحلة أو دون الصلاحية يُرفض |
| DOC-01 | إنشاء وثيقة يسمح بمزود ومستهلك واحد لكل طرف ويتحقق من عدم تطابق النظام الداخلي |
| DOC-02 | إنشاء تكامل ثانٍ للوثيقة نفسها يعيد 409 ويمنع السباق |
| FILE-01 | لا يُرسل مستند ناقص الإلزاميات ولا ملف ترفضه قواعد النوع والحجم والفحص |
| FILE-02 | لا يمكن تعديل مراجعة معتمدة، ولو بتغيير معرف الملف في الطلب |
| CHANGE-01 | طلب تغيير غير معتمد لا يسمح بإنشاء نسخة عمل معدلة |
| CHANGE-02 | الملفات غير المدرجة في طلب تغيير معتمد لا تقبل الاستبدال |
| WF-01 | عضوان من الدور نفسه يحاولان الاعتماد بالتزامن؛ قرار واحد فقط مؤثر |
| WF-02 | تغيير إعدادات مسار الاعتماد لا يغير سير معاملات جارية |
| WF-03 | موافقة المرحلة الأخيرة تنهي المسار؛ لا يوجد نوع مرحلة منفصل |
| WF-04 | دور لا يوجد فيه عضو نشط ومخول يسبب منع تقديم واضح |
| VERS-01 | قبول تسمية إصدار حر مثل V2026؛ منع التكرار داخل التكامل |
| VERS-02 | وجود مراجعتين للملفات تحت إصدار API واحد مع بقاء الأولى غير قابلة للتغيير |
| PUB-01 | رفض نشر مراجعة غير معتمدة |
| PUB-02 | تعيين إصدار مستخدم لا يلغي إصدارات منشورة أخرى |
| PORT-01 | مستهلك الجهة A لا ينزّل ملفات الجهة B حتى برابط مباشر |
| PORT-02 | بعد إيقاف النشر يُرفض تنزيل الرابط القديم فورًا |
| AUD-01 | كل قرار وتغيير منح وسحب ونشر وتنزيل يولّد حدثًا قابلًا للتتبع |
| ERR-01 | إعادة محاولة نشر أو قرار اعتماد لا تضاعف السجلات |

## 10. افتراضات وتفاصيل لم تُحسم
- طريقة المصادقة الداخلية والخارجية (SSO أم إدارة حسابات محلية مؤقتة) تحتاج قرارًا بعد تقييم الواقع المؤسسي؛ Windows Server احتمال لا اختيار إلزامي.
- تعيين مسؤول واحد من أعضاء الدور كموافق كافٍ لكل مرحلة معتمد، لكن **إعادة/رفض مقابل موافقة متعددة بالتزامن** يحتاج تعريف أولوية ومعالجة سباق آمنة.
- صلاحية المراجع على وثيقة مقيدة: اقترح منح وصول مهمة مؤقت محدود؛ ينبغي اعتماد تفاصيله عند تصميم سياسة التفويض.
- إذا تعارضت منح وسحب الأدوار على وثيقة واحدة، فقاعدة الفصل تحتاج اعتمادًا صريحًا؛ الاستثناء الفردي واضح وذو أولوية.
- أسماء أكواد الصلاحيات المعروضة في كتالوج المسارات أمثلة مقترحة ولم تعتمد كقاموس نهائي؛ يجب جرد كامل صلاحيات المصفوفة المعتمدة قبل التنفيذ.
- مقاسات الملفات ومعدلات الاستخدام والعزل بين جهات خارجية والمدة التنظيمية للاحتفاظ لم تحدد بعد، لذا لم تُضف حدودًا رقمية من عندنا.
- لا تمارس خدمة Backend ترقية API التقنية نفسها؛ المطور المخول ينفذها خارج المنصة ثم يوثق الناتج داخلها.

## 11. حزمة التسليم ومعيار عبور البوابة
**المخرجات:** مخطط وحدات الخادم، كتالوج 93 واجهة أولية، سياسة تفويض قابلة للتنفيذ، انتقالات الحالات، سيناريوهات تحقق وأخطاء، وربط مع الجداول المعتمدة.
**معيار الاكتمال لهذه الخطوة:** مراجعة أن كل إجراء UI لديه خدمة خلفية ومعيار تصريح؛ وأن انتقالات الحالات محمية ذريًا؛ وأن مكوّن التخزين لا يتيح وصولًا مباشرًا غير مرخص؛ وأن جميع الافتراضات الحرجة موثقة دون الادعاء بتنفيذها.
**الخطوة التالية داخل المرحلة الخامسة:** تصميم محرك مسارات الاعتماد وقواعد حالات التغيير والنشر بالتفصيل، ثم تحديد الأنماط التقنية قبل كتابة أو نشر أي كود إنتاجي.
